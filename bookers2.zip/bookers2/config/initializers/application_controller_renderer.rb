# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '4c4b0a8a19b3877035994a99ea5cbfb4a7583a6f056b8ce8da654c9c8393803f380bad665dd37a40cb9ec8fcd47b780f1815fb19d37d73e60734d848c971cb16'
